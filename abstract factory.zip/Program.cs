﻿using System;

namespace SolidExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Hangi araba tipini üretmek istersin? (Sedan / SUV)");
                string tip = Console.ReadLine();

                Araba araba = ArabaFabrikasi.Uret(tip);
                araba.Sur(); // Dinamik olarak üretilen arabayı sür

                Console.WriteLine("Araba başarıyla üretildi ve sürüldü.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hata: {ex.Message}");
            }

            Console.ReadLine();
        }
    }

    // Soyut sınıf
    public abstract class Araba
    {
        public abstract void Sur();
    }

    // Sedan sınıfı
    public class Sedan : Araba
    {
        public override void Sur() => Console.WriteLine("Sedan sürülüyor");
    }

    // SUV sınıfı
    public class SUV : Araba
    {
        public override void Sur() => Console.WriteLine("SUV sürülüyor");
    }

    // Fabrika sınıfı
    public class ArabaFabrikasi
    {
        public static Araba Uret(string tip)
        {
            if (tip == "Sedan") return new Sedan();
            if (tip == "SUV") return new SUV();
            throw new Exception("Bilinmeyen araba tipi");
        }
    }
}
