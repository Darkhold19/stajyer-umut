﻿using System;
using System.Collections.Generic;

namespace SolidExamples
{
    // ------------------ 1. Singleton ------------------

    public class ElektrikSayaci
    {
        private static ElektrikSayaci _instance;
        private static readonly object _lock = new object();
        private ElektrikSayaci() { }

        public static ElektrikSayaci Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new ElektrikSayaci();
                    }
                    return _instance;
                }
            }
        }

        public void OlcumYap()
        {
            Console.WriteLine("[Singleton] Ölçüm yapıldı.");
        }
    }

    // ------------------ 2. Factory ------------------

    public abstract class Araba
    {
        public abstract void Sur();
    }

    public class Sedan : Araba
    {
        public override void Sur()
        {
            Console.WriteLine("[Factory] Sedan sürülüyor.");
        }
    }

    public class SUV : Araba
    {
        public override void Sur()
        {
            Console.WriteLine("[Factory] SUV sürülüyor.");
        }
    }

    public class ArabaFabrikasi
    {
        public static Araba Uret(string tip)
        {
            switch (tip)
            {
                case "Sedan":
                    return new Sedan();
                case "SUV":
                    return new SUV();
                default:
                    throw new Exception("Bilinmeyen araba tipi");
            }
        }
    }

    // ------------------ 3. Bridge ------------------

    public interface ICihaz
    {
        void Ac();
        void Kapat();
    }

    public class Televizyon : ICihaz
    {
        public void Ac()
        {
            Console.WriteLine("[Bridge] TV açıldı.");
        }

        public void Kapat()
        {
            Console.WriteLine("[Bridge] TV kapatıldı.");
        }
    }

    public class Kumanda
    {
        protected ICihaz _cihaz;

        public Kumanda(ICihaz cihaz)
        {
            _cihaz = cihaz;
        }

        public virtual void Ac()
        {
            _cihaz.Ac();
        }

        public virtual void Kapat()
        {
            _cihaz.Kapat();
        }
    }

    public class GelismisKumanda : Kumanda
    {
        public GelismisKumanda(ICihaz cihaz) : base(cihaz) { }

        public void SesAc()
        {
            Console.WriteLine("[Bridge] Ses açıldı.");
        }
    }

    // ------------------ 4. Composite ------------------

    public interface IDosyaSistemi
    {
        void Goster();
    }

    public class Dosya : IDosyaSistemi
    {
        private string _isim;

        public Dosya(string isim)
        {
            _isim = isim;
        }

        public void Goster()
        {
            Console.WriteLine("[Composite] Dosya: " + _isim);
        }
    }

    public class Klasor : IDosyaSistemi
    {
        private string _isim;
        private List<IDosyaSistemi> _icerikler = new List<IDosyaSistemi>();

        public Klasor(string isim)
        {
            _isim = isim;
        }

        public void Ekle(IDosyaSistemi eleman)
        {
            _icerikler.Add(eleman);
        }

        public void Goster()
        {
            Console.WriteLine("[Composite] Klasör: " + _isim);
            foreach (var eleman in _icerikler)
            {
                eleman.Goster();
            }
        }
    }

    // ------------------ 5. Strategy ------------------

    public interface IGuzergah
    {
        void YolHesapla();
    }

    public class ArabaIle : IGuzergah
    {
        public void YolHesapla()
        {
            Console.WriteLine("[Strategy] Araba ile rota.");
        }
    }

    public class Yuruyerek : IGuzergah
    {
        public void YolHesapla()
        {
            Console.WriteLine("[Strategy] Yürüyerek rota.");
        }
    }

    public class Navigasyon
    {
        private IGuzergah _yolStratejisi;

        public Navigasyon(IGuzergah strateji)
        {
            _yolStratejisi = strateji;
        }

        public void RotaCiz()
        {
            _yolStratejisi.YolHesapla();
        }
    }

    // ------------------ 6. Observer ------------------

    public class HavaMerkezi
    {
        public delegate void HavaDurumuHandler(string durum);
        public event HavaDurumuHandler HavaDurumuDegisti;

        public void Guncelle(string yeniDurum)
        {
            if (HavaDurumuDegisti != null)
            {
                HavaDurumuDegisti(yeniDurum);
            }
        }
    }

    public class Kullanici
    {
        public Kullanici(HavaMerkezi merkez)
        {
            merkez.HavaDurumuDegisti += HavaGuncelle;
        }

        public void HavaGuncelle(string durum)
        {
            Console.WriteLine("[Observer] Yeni hava durumu: " + durum);
        }
    }

    // ------------------ Main Program ------------------
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Design Pattern Örnekleri Başlıyor ===\n");

            // Singleton
            ElektrikSayaci.Instance.OlcumYap();

            // Factory
            var araba = ArabaFabrikasi.Uret("SUV");
            araba.Sur();

            // Bridge
            ICihaz tv = new Televizyon();
            var kumanda = new GelismisKumanda(tv);
            kumanda.Ac();
            kumanda.SesAc();
            kumanda.Kapat();

            // Composite
            var klasor = new Klasor("Belgeler");
            klasor.Ekle(new Dosya("cv.docx"));
            klasor.Ekle(new Dosya("foto.jpg"));
            klasor.Goster();

            // Strategy
            var navigasyon = new Navigasyon(new ArabaIle());
            navigasyon.RotaCiz();

            navigasyon = new Navigasyon(new Yuruyerek());
            navigasyon.RotaCiz();

            // Observer
            var merkez = new HavaMerkezi();
            var user1 = new Kullanici(merkez);
            merkez.Guncelle("Yağmurlu");

            Console.WriteLine("\n=== Design Pattern Örnekleri Bitti ===");
        }
    }
}
